
import { createConnection } from "mysql2/promise";

async function check() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  const [rows] = await conn.execute("SELECT id, employeeId, workDate, HEX(workDate) as hex, LENGTH(workDate) as len, isWorking FROM workSchedules LIMIT 20");
  console.log("workSchedules sample:");
  console.table(rows);

  await conn.end();
}

check().catch(console.error);
