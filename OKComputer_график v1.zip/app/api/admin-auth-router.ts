import * as cookie from "cookie";
import { Session } from "@contracts/constants";
import { getSessionCookieOptions } from "./lib/cookies";
import { signSessionToken, verifySessionToken } from "./kimi/session";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb, users } from "./queries/connection";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

const ADMIN_LOGIN = "Ushakov";
const ADMIN_PASSWORD = "Ushakov1987";

export const adminAuthRouter = createRouter({
  login: publicQuery
    .input(z.object({ login: z.string(), password: z.string() }))
    .mutation(async ({ input, ctx }) => {
      if (input.login !== ADMIN_LOGIN || input.password !== ADMIN_PASSWORD) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Неверный логин или пароль" });
      }

      const db = getDb();
      const unionId = "admin_local";

      let user = await db.select().from(users).where(eq(users.unionId, unionId)).limit(1).then((rows) => rows.at(0));

      if (!user) {
        await db.insert(users).values({
          unionId, name: "Администратор", role: "admin",
          createdAt: Date.now(), updatedAt: Date.now(), lastSignInAt: Date.now(),
        });
        user = await db.select().from(users).where(eq(users.unionId, unionId)).limit(1).then((rows) => rows.at(0));
      } else {
        await db.update(users).set({ lastSignInAt: Date.now() }).where(eq(users.id, user.id));
      }

      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create admin" });

      const token = await signSessionToken({ unionId, clientId: "admin" });

      const cookieOpts = getSessionCookieOptions();
      ctx.resHeaders.append("set-cookie", cookie.serialize(Session.cookieName, token, {
        httpOnly: cookieOpts.httpOnly, path: cookieOpts.path,
        sameSite: cookieOpts.sameSite as "lax",
        secure: cookieOpts.secure, maxAge: Session.maxAgeMs / 1000,
      }));

      return { success: true, user: { id: user.id, name: user.name, role: user.role, email: user.email, avatar: user.avatar } };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const cookies = cookie.parse(ctx.req.headers.get("cookie") || "");
    const token = cookies[Session.cookieName];
    if (!token) return null;
    const claim = await verifySessionToken(token);
    if (!claim) return null;
    const user = await getDb().select().from(users).where(eq(users.unionId, claim.unionId)).limit(1).then((rows) => rows.at(0));
    return user ?? null;
  }),

  logout: authedQuery.mutation(async ({ ctx }) => {
    ctx.resHeaders.append("set-cookie", cookie.serialize(Session.cookieName, "", {
      httpOnly: true, path: "/",
      sameSite: "lax" as const,
      maxAge: 0,
    }));
    return { success: true };
  }),
});
