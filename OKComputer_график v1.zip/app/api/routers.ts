import { z } from "zod";
import { createRouter, publicQuery, authedQuery, adminQuery } from "./middleware";
import { getDb, employees, workSchedules, shiftReports, cashTransactions } from "./queries/connection";
import { eq, and, gte, lte, desc, count, sum } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const employeeRouter = createRouter({
  list: publicQuery.query(async () => {
    return getDb().select().from(employees).where(eq(employees.isActive, true));
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const [emp] = await getDb().select().from(employees).where(eq(employees.id, input.id));
      return emp ?? null;
    }),

  create: adminQuery
    .input(z.object({ name: z.string().min(1), baseSalary: z.coerce.number().optional(), commissionRate: z.coerce.number().optional() }))
    .mutation(async ({ input }) => {
      const [newEmp] = await getDb().insert(employees).values({
        name: input.name,
        baseSalary: input.baseSalary ?? 2300,
        commissionRate: input.commissionRate ?? 3,
      }).returning();
      return { id: newEmp.id };
    }),

  update: adminQuery
    .input(z.object({ id: z.number(), name: z.string().min(1).optional(), baseSalary: z.coerce.number().optional(), commissionRate: z.coerce.number().optional(), isActive: z.boolean().optional() }))
    .mutation(async ({ input }) => {
      await getDb().update(employees).set({
        ...(input.name && { name: input.name }),
        ...(input.baseSalary !== undefined && { baseSalary: input.baseSalary }),
        ...(input.commissionRate !== undefined && { commissionRate: input.commissionRate }),
        ...(input.isActive !== undefined && { isActive: input.isActive }),
      }).where(eq(employees.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(employees).where(eq(employees.id, input.id));
      return { success: true };
    }),
});

export const scheduleRouter = createRouter({
  listByEmployee: publicQuery
    .input(z.object({ employeeId: z.number() }))
    .query(async ({ input }) => {
      return getDb().select().from(workSchedules).where(eq(workSchedules.employeeId, input.employeeId)).orderBy(workSchedules.workDate);
    }),

  listByMonth: publicQuery
    .input(z.object({ year: z.number(), month: z.number() }))
    .query(async ({ input }) => {
      const startDate = `${input.year}-${String(input.month).padStart(2, "0")}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, "0")}-31`;
      return getDb().select().from(workSchedules)
        .where(and(gte(workSchedules.workDate, startDate), lte(workSchedules.workDate, endDate)))
        .orderBy(workSchedules.workDate);
    }),

  setDay: authedQuery
    .input(z.object({ employeeId: z.number(), workDate: z.string(), isWorking: z.boolean() }))
    .mutation(async ({ input }) => {
      const existing = await getDb().select().from(workSchedules)
        .where(and(eq(workSchedules.employeeId, input.employeeId), eq(workSchedules.workDate, input.workDate)));

      if (existing.length > 0) {
        await getDb().update(workSchedules).set({ isWorking: input.isWorking }).where(eq(workSchedules.id, existing[0].id));
        return { updated: true };
      } else {
        await getDb().insert(workSchedules).values({
          employeeId: input.employeeId,
          workDate: input.workDate,
          isWorking: input.isWorking,
        });
        return { created: true };
      }
    }),

  countWorkingDays: publicQuery
    .input(z.object({ employeeId: z.number(), year: z.number(), month: z.number() }))
    .query(async ({ input }) => {
      const startDate = `${input.year}-${String(input.month).padStart(2, "0")}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, "0")}-31`;
      const result = await getDb().select({ count: count() }).from(workSchedules)
        .where(and(eq(workSchedules.employeeId, input.employeeId), eq(workSchedules.isWorking, true), gte(workSchedules.workDate, startDate), lte(workSchedules.workDate, endDate)));
      return result[0]?.count ?? 0;
    }),
});

export const reportRouter = createRouter({
  listByEmployee: publicQuery
    .input(z.object({ employeeId: z.number() }))
    .query(async ({ input }) => {
      return getDb().select().from(shiftReports).where(eq(shiftReports.employeeId, input.employeeId)).orderBy(desc(shiftReports.reportDate));
    }),

  listByMonth: publicQuery
    .input(z.object({ employeeId: z.number(), year: z.number(), month: z.number() }))
    .query(async ({ input }) => {
      const startDate = `${input.year}-${String(input.month).padStart(2, "0")}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, "0")}-31`;
      return getDb().select().from(shiftReports)
        .where(and(eq(shiftReports.employeeId, input.employeeId), gte(shiftReports.reportDate, startDate), lte(shiftReports.reportDate, endDate)))
        .orderBy(desc(shiftReports.reportDate));
    }),

  getByDate: publicQuery
    .input(z.object({ employeeId: z.number(), date: z.string() }))
    .query(async ({ input }) => {
      const [report] = await getDb().select().from(shiftReports)
        .where(and(eq(shiftReports.employeeId, input.employeeId), eq(shiftReports.reportDate, input.date)));
      return report ?? null;
    }),

  createOrUpdate: authedQuery
    .input(z.object({ employeeId: z.number(), reportDate: z.string(), revenue: z.coerce.number(), cashStart: z.coerce.number().optional(), cashEnd: z.coerce.number().optional(), notes: z.string().optional() }))
    .mutation(async ({ input }) => {
      const [emp] = await getDb().select().from(employees).where(eq(employees.id, input.employeeId));
      if (!emp) throw new TRPCError({ code: "NOT_FOUND", message: "Employee not found" });

      const revenue = input.revenue;
      const commissionRate = Number(emp.commissionRate);
      const baseSalary = Number(emp.baseSalary);
      const commission = revenue * (commissionRate / 100);
      const salaryTotal = baseSalary + commission;

      const existing = await getDb().select().from(shiftReports)
        .where(and(eq(shiftReports.employeeId, input.employeeId), eq(shiftReports.reportDate, input.reportDate)));

      if (existing.length > 0) {
        await getDb().update(shiftReports).set({
          revenue: input.revenue,
          commission: commission,
          salaryTotal: salaryTotal,
          cashStart: input.cashStart ?? existing[0].cashStart,
          cashEnd: input.cashEnd ?? existing[0].cashEnd,
          notes: input.notes ?? existing[0].notes,
        }).where(eq(shiftReports.id, existing[0].id));
        return { updated: true, commission, salaryTotal };
      } else {
        const [newReport] = await getDb().insert(shiftReports).values({
          employeeId: input.employeeId,
          reportDate: input.reportDate,
          revenue: input.revenue,
          commission: commission,
          salaryTotal: salaryTotal,
          cashStart: input.cashStart ?? 0,
          cashEnd: input.cashEnd ?? 0,
          notes: input.notes ?? null,
        }).returning();
        return { created: true, id: newReport.id, commission, salaryTotal };
      }
    }),
});

export const cashRouter = createRouter({
  listByEmployee: publicQuery
    .input(z.object({ employeeId: z.number() }))
    .query(async ({ input }) => {
      return getDb().select().from(cashTransactions).where(eq(cashTransactions.employeeId, input.employeeId)).orderBy(desc(cashTransactions.transactionDate));
    }),

  listByDateRange: publicQuery
    .input(z.object({ start: z.string(), end: z.string() }))
    .query(async ({ input }) => {
      return getDb().select().from(cashTransactions)
        .where(and(gte(cashTransactions.transactionDate, input.start), lte(cashTransactions.transactionDate, input.end)))
        .orderBy(desc(cashTransactions.transactionDate));
    }),

  create: authedQuery
    .input(z.object({ employeeId: z.number(), transactionDate: z.string(), type: z.enum(["income", "expense"]), amount: z.coerce.number(), description: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const [tx] = await getDb().insert(cashTransactions).values({
        employeeId: input.employeeId,
        transactionDate: input.transactionDate,
        type: input.type,
        amount: input.amount,
        description: input.description,
      }).returning();
      return { id: tx.id };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(cashTransactions).where(eq(cashTransactions.id, input.id));
      return { success: true };
    }),

  getBalance: publicQuery
    .input(z.object({ date: z.string() }))
    .query(async ({ input }) => {
      const income = await getDb().select({ total: sum(cashTransactions.amount) }).from(cashTransactions)
        .where(and(eq(cashTransactions.type, "income"), lte(cashTransactions.transactionDate, input.date)));
      const expense = await getDb().select({ total: sum(cashTransactions.amount) }).from(cashTransactions)
        .where(and(eq(cashTransactions.type, "expense"), lte(cashTransactions.transactionDate, input.date)));
      return { balance: Number(income[0]?.total ?? 0) - Number(expense[0]?.total ?? 0) };
    }),
});

export const analyticsRouter = createRouter({
  getDashboard: adminQuery.query(async () => {
    const totalEmployees = await getDb().select({ count: count() }).from(employees).where(eq(employees.isActive, true));
    const totalReports = await getDb().select({ count: count() }).from(shiftReports);
    const totalRevenue = await getDb().select({ total: sum(shiftReports.revenue) }).from(shiftReports);
    const totalSalaries = await getDb().select({ total: sum(shiftReports.salaryTotal) }).from(shiftReports);
    return {
      totalEmployees: totalEmployees[0]?.count ?? 0,
      totalReports: totalReports[0]?.count ?? 0,
      totalRevenue: Number(totalRevenue[0]?.total ?? 0),
      totalSalaries: Number(totalSalaries[0]?.total ?? 0),
    };
  }),

  getRevenueByEmployee: adminQuery
    .input(z.object({ year: z.number(), month: z.number() }))
    .query(async ({ input }) => {
      const startDate = `${input.year}-${String(input.month).padStart(2, "0")}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, "0")}-31`;
      return getDb().select({
        employeeId: shiftReports.employeeId,
        totalRevenue: sum(shiftReports.revenue),
        totalCommission: sum(shiftReports.commission),
        totalSalary: sum(shiftReports.salaryTotal),
      }).from(shiftReports)
        .where(and(gte(shiftReports.reportDate, startDate), lte(shiftReports.reportDate, endDate)))
        .groupBy(shiftReports.employeeId);
    }),

  getEmployeeStats: adminQuery
    .input(z.object({ employeeId: z.number(), year: z.number(), month: z.number() }))
    .query(async ({ input }) => {
      const startDate = `${input.year}-${String(input.month).padStart(2, "0")}-01`;
      const endDate = `${input.year}-${String(input.month).padStart(2, "0")}-31`;
      const [emp] = await getDb().select().from(employees).where(eq(employees.id, input.employeeId));
      if (!emp) return null;
      const reports = await getDb().select().from(shiftReports)
        .where(and(eq(shiftReports.employeeId, input.employeeId), gte(shiftReports.reportDate, startDate), lte(shiftReports.reportDate, endDate)));
      const workingDays = await getDb().select({ count: count() }).from(workSchedules)
        .where(and(eq(workSchedules.employeeId, input.employeeId), eq(workSchedules.isWorking, true), gte(workSchedules.workDate, startDate), lte(workSchedules.workDate, endDate)));
      return {
        employee: emp,
        workingDays: workingDays[0]?.count ?? 0,
        reportsCount: reports.length,
        totalRevenue: reports.reduce((s, r) => s + Number(r.revenue), 0),
        totalCommission: reports.reduce((s, r) => s + Number(r.commission), 0),
        totalSalary: reports.reduce((s, r) => s + Number(r.salaryTotal), 0),
      };
    }),

  getAllTransactions: adminQuery
    .input(z.object({ start: z.string(), end: z.string() }))
    .query(async ({ input }) => {
      return getDb().select().from(cashTransactions)
        .where(and(gte(cashTransactions.transactionDate, input.start), lte(cashTransactions.transactionDate, input.end)))
        .orderBy(desc(cashTransactions.transactionDate));
    }),

  getCashFlow: adminQuery
    .input(z.object({ start: z.string(), end: z.string() }))
    .query(async ({ input }) => {
      const income = await getDb().select({ total: sum(cashTransactions.amount) }).from(cashTransactions)
        .where(and(eq(cashTransactions.type, "income"), gte(cashTransactions.transactionDate, input.start), lte(cashTransactions.transactionDate, input.end)));
      const expense = await getDb().select({ total: sum(cashTransactions.amount) }).from(cashTransactions)
        .where(and(eq(cashTransactions.type, "expense"), gte(cashTransactions.transactionDate, input.start), lte(cashTransactions.transactionDate, input.end)));
      return { income: Number(income[0]?.total ?? 0), expense: Number(expense[0]?.total ?? 0), balance: Number(income[0]?.total ?? 0) - Number(expense[0]?.total ?? 0) };
    }),
});
