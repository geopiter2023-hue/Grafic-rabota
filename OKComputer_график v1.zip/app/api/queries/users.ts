import { eq } from "drizzle-orm";
import { users } from "./connection";
import { getDb } from "./connection";

type DbUser = typeof users.$inferSelect;

export async function findUserByUnionId(unionId: string): Promise<DbUser | undefined> {
  const result = await getDb().select().from(users).where(eq(users.unionId, unionId)).limit(1);
  return result[0];
}

export async function createUser(data: {
  unionId: string;
  name?: string | null;
  email?: string | null;
  avatar?: string | null;
}): Promise<DbUser> {
  const [user] = await getDb()
    .insert(users)
    .values({
      unionId: data.unionId,
      name: data.name,
      email: data.email,
      avatar: data.avatar,
      role: "user",
      createdAt: Date.now(),
      updatedAt: Date.now(),
      lastSignInAt: Date.now(),
    })
    .onConflictDoUpdate({
      target: users.unionId,
      set: {
        name: data.name,
        email: data.email,
        avatar: data.avatar,
        updatedAt: Date.now(),
      },
    })
    .returning();
  return user;
}

export async function upsertUser(data: {
  unionId: string;
  name?: string | null;
  avatar?: string | null;
  lastSignInAt?: Date;
}): Promise<void> {
  const now = Date.now();
  await getDb()
    .insert(users)
    .values({
      unionId: data.unionId,
      name: data.name,
      avatar: data.avatar,
      role: "user",
      createdAt: now,
      updatedAt: now,
      lastSignInAt: data.lastSignInAt ? data.lastSignInAt.getTime() : now,
    })
    .onConflictDoUpdate({
      target: users.unionId,
      set: {
        name: data.name,
        avatar: data.avatar,
        updatedAt: now,
        lastSignInAt: data.lastSignInAt ? data.lastSignInAt.getTime() : now,
      },
    });
}

export async function updateUserLastSignIn(unionId: string): Promise<void> {
  await getDb()
    .update(users)
    .set({ lastSignInAt: Date.now() })
    .where(eq(users.unionId, unionId));
}
