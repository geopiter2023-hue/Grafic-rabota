import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "@db/schema";

const client = new Database("./local.db");
client.pragma("journal_mode = WAL");
client.pragma("foreign_keys = ON");

export const db = drizzle(client, { schema });

export function getDb() {
  return db;
}

// Init tables + seed admin
client.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    union_id TEXT NOT NULL UNIQUE,
    name TEXT,
    email TEXT,
    avatar TEXT,
    role TEXT NOT NULL DEFAULT 'user',
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0,
    last_signin_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    base_salary REAL NOT NULL DEFAULT 2300,
    commission_rate REAL NOT NULL DEFAULT 3,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS work_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    work_date TEXT NOT NULL,
    is_working INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0,
    UNIQUE(employee_id, work_date)
  );
  CREATE TABLE IF NOT EXISTS shift_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    report_date TEXT NOT NULL,
    revenue REAL NOT NULL DEFAULT 0,
    commission REAL NOT NULL DEFAULT 0,
    salary_total REAL NOT NULL DEFAULT 0,
    cash_start REAL NOT NULL DEFAULT 0,
    cash_end REAL NOT NULL DEFAULT 0,
    notes TEXT,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS cash_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    transaction_date TEXT NOT NULL,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    description TEXT NOT NULL,
    created_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sku TEXT,
    barcode TEXT,
    category TEXT NOT NULL DEFAULT 'Общее',
    cost_price REAL NOT NULL DEFAULT 0,
    price REAL NOT NULL DEFAULT 0,
    markup_percent REAL NOT NULL DEFAULT 0,
    quantity INTEGER NOT NULL DEFAULT 0,
    min_quantity INTEGER NOT NULL DEFAULT 5,
    unit TEXT NOT NULL DEFAULT 'шт',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS inventory_counts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    count_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS inventory_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inventory_id INTEGER NOT NULL REFERENCES inventory_counts(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    expected_qty INTEGER NOT NULL DEFAULT 0,
    actual_qty INTEGER NOT NULL DEFAULT 0,
    difference INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    created_at INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0
  );
`);

const adminExists = client.prepare("SELECT 1 FROM users WHERE union_id = 'admin_1987'").get();
if (!adminExists) {
  const now = Date.now();
  client.prepare("INSERT INTO users (union_id, name, role, created_at, updated_at, last_signin_at) VALUES (?, ?, ?, ?, ?, ?)")
    .run("admin_1987", "Administrator", "admin", now, now, now);
}

// Re-export schema for convenience
export {
  users, employees, workSchedules, shiftReports,
  cashTransactions, products, inventoryCounts, inventoryItems,
} from "@db/schema";

export type {
  User, Employee, WorkSchedule, ShiftReport,
  CashTransaction, Product, InventoryCount, InventoryItem,
} from "@db/schema";
