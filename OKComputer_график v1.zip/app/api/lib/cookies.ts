import type { CookieOptions } from "hono/utils/cookie";

export function getSessionCookieOptions(): CookieOptions {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "Lax",
    secure: false,
  };
}
