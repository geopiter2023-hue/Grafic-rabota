import { adminAuthRouter } from "./admin-auth-router";
import { createRouter, publicQuery } from "./middleware";
import { employeeRouter, scheduleRouter, reportRouter, cashRouter, analyticsRouter } from "./routers";
import { productRouter, inventoryRouter } from "./product-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: adminAuthRouter,
  employee: employeeRouter,
  schedule: scheduleRouter,
  report: reportRouter,
  cash: cashRouter,
  analytics: analyticsRouter,
  product: productRouter,
  inventory: inventoryRouter,
});

export type AppRouter = typeof appRouter;
