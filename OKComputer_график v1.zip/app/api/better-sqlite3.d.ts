declare module "better-sqlite3" {
  class Database {
    constructor(filename: string, options?: { readonly?: boolean; fileMustExist?: boolean; timeout?: number; verbose?: (message: unknown) => void });
    prepare(sql: string): {
      run(...params: unknown[]): { changes: number; lastInsertRowid: number | bigint };
      get(...params: unknown[]): unknown;
      all(...params: unknown[]): unknown[];
      iterate(...params: unknown[]): IterableIterator<unknown>;
    };
    exec(sql: string): void;
    pragma(pragma: string, options?: { simple?: boolean }): unknown;
    close(): void;
    readonly: boolean;
    name: string;
    open: boolean;
    inTransaction: boolean;
  }
  export = Database;
  export { Database as default };
}
