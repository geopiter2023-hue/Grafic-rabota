import { z } from "zod";
import { createRouter, publicQuery, authedQuery, adminQuery } from "./middleware";
import { getDb, products, inventoryCounts, inventoryItems } from "./queries/connection";
import { eq, desc, count, like, or } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const productRouter = createRouter({
  list: publicQuery.query(async () => {
    return getDb().select().from(products).where(eq(products.isActive, true)).orderBy(products.name);
  }),

  search: publicQuery
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      const q = `%${input.query}%`;
      return getDb().select().from(products).where(
        or(like(products.name, q), like(products.sku, q), like(products.barcode, q), like(products.category, q))
      ).orderBy(products.name);
    }),

  findByBarcode: publicQuery
    .input(z.object({ barcode: z.string() }))
    .query(async ({ input }) => {
      const [p] = await getDb().select().from(products).where(eq(products.barcode, input.barcode));
      return p ?? null;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const [p] = await getDb().select().from(products).where(eq(products.id, input.id));
      return p ?? null;
    }),

  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      sku: z.string().optional(),
      barcode: z.string().optional(),
      category: z.string().optional(),
      costPrice: z.coerce.number().optional(),
      price: z.coerce.number().optional(),
      markupPercent: z.coerce.number().optional(),
      quantity: z.number().optional(),
      minQuantity: z.number().optional(),
      unit: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const cost = input.costPrice ?? 0;
      const markup = input.markupPercent ?? 0;
      const calcPrice = cost > 0 && markup > 0 ? cost * (1 + markup / 100) : (input.price ?? 0);
      const [p] = await getDb().insert(products).values({
        name: input.name,
        sku: input.sku ?? null,
        barcode: input.barcode ?? null,
        category: input.category ?? "Общее",
        costPrice: cost,
        price: calcPrice,
        markupPercent: markup,
        quantity: input.quantity ?? 0,
        minQuantity: input.minQuantity ?? 5,
        unit: input.unit ?? "шт",
      }).returning();
      return { id: p.id };
    }),

  update: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      sku: z.string().optional(),
      barcode: z.string().optional(),
      category: z.string().optional(),
      costPrice: z.coerce.number().optional(),
      price: z.coerce.number().optional(),
      markupPercent: z.coerce.number().optional(),
      quantity: z.number().optional(),
      minQuantity: z.number().optional(),
      unit: z.string().optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      const setData: Record<string, unknown> = {};
      if (input.name) setData.name = input.name;
      if (input.sku !== undefined) setData.sku = input.sku;
      if (input.barcode !== undefined) setData.barcode = input.barcode;
      if (input.category) setData.category = input.category;
      if (input.costPrice !== undefined) setData.costPrice = input.costPrice;
      if (input.price !== undefined) setData.price = input.price;
      if (input.markupPercent !== undefined) setData.markupPercent = input.markupPercent;
      if (input.quantity !== undefined) setData.quantity = input.quantity;
      if (input.minQuantity !== undefined) setData.minQuantity = input.minQuantity;
      if (input.unit) setData.unit = input.unit;
      if (input.isActive !== undefined) setData.isActive = input.isActive;

      if (input.costPrice !== undefined && input.markupPercent !== undefined) {
        const cost = input.costPrice;
        const markup = input.markupPercent;
        if (cost > 0 && markup >= 0) setData.price = cost * (1 + markup / 100);
      }

      await getDb().update(products).set(setData).where(eq(products.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().update(products).set({ isActive: false }).where(eq(products.id, input.id));
      return { success: true };
    }),

  bulkImport: adminQuery
    .input(z.object({
      items: z.array(z.object({
        name: z.string().min(1),
        sku: z.string().optional(),
        barcode: z.string().optional(),
        category: z.string().optional(),
        costPrice: z.coerce.number().optional(),
        price: z.coerce.number().optional(),
        markupPercent: z.coerce.number().optional(),
        quantity: z.number().optional(),
        unit: z.string().optional(),
      })),
    }))
    .mutation(async ({ input }) => {
      let imported = 0;
      for (const item of input.items) {
        const cost = item.costPrice ?? 0;
        const markup = item.markupPercent ?? 0;
        const price = cost > 0 && markup > 0 ? cost * (1 + markup / 100) : (item.price ?? 0);
        await getDb().insert(products).values({
          name: item.name,
          sku: item.sku ?? null,
          barcode: item.barcode ?? null,
          category: item.category ?? "Общее",
          costPrice: cost,
          price,
          markupPercent: markup,
          quantity: item.quantity ?? 0,
          unit: item.unit ?? "шт",
        });
        imported++;
      }
      return { imported };
    }),

  applyMarkup: adminQuery
    .input(z.object({ ids: z.array(z.number()), markupPercent: z.number().min(0) }))
    .mutation(async ({ input }) => {
      let updated = 0;
      for (const id of input.ids) {
        const [p] = await getDb().select().from(products).where(eq(products.id, id));
        if (!p) continue;
        const cost = Number(p.costPrice);
        if (cost > 0) {
          await getDb().update(products).set({
            price: cost * (1 + input.markupPercent / 100),
            markupPercent: input.markupPercent,
          }).where(eq(products.id, id));
          updated++;
        }
      }
      return { updated };
    }),
});

export const inventoryRouter = createRouter({
  list: publicQuery.query(async () => {
    return getDb().select().from(inventoryCounts).orderBy(desc(inventoryCounts.createdAt));
  }),

  listByEmployee: publicQuery
    .input(z.object({ employeeId: z.number() }))
    .query(async ({ input }) => {
      return getDb().select().from(inventoryCounts).where(eq(inventoryCounts.employeeId, input.employeeId)).orderBy(desc(inventoryCounts.createdAt));
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const [inv] = await getDb().select().from(inventoryCounts).where(eq(inventoryCounts.id, input.id));
      if (!inv) return null;
      const items = await getDb().select().from(inventoryItems).where(eq(inventoryItems.inventoryId, input.id));
      return { ...inv, items };
    }),

  create: authedQuery
    .input(z.object({ employeeId: z.number(), countDate: z.string(), notes: z.string().optional() }))
    .mutation(async ({ input }) => {
      const allProducts = await getDb().select().from(products).where(eq(products.isActive, true));
      const [inv] = await getDb().insert(inventoryCounts).values({
        employeeId: input.employeeId,
        countDate: input.countDate,
        status: "draft",
        notes: input.notes ?? null,
      }).returning();
      for (const p of allProducts) {
        await getDb().insert(inventoryItems).values({
          inventoryId: inv.id,
          productId: p.id,
          expectedQty: p.quantity,
          actualQty: p.quantity,
          difference: 0,
        });
      }
      return { id: inv.id };
    }),

  updateItem: authedQuery
    .input(z.object({ itemId: z.number(), actualQty: z.number(), notes: z.string().optional() }))
    .mutation(async ({ input }) => {
      const [item] = await getDb().select().from(inventoryItems).where(eq(inventoryItems.id, input.itemId));
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Item not found" });
      const diff = input.actualQty - item.expectedQty;
      await getDb().update(inventoryItems).set({
        actualQty: input.actualQty,
        difference: diff,
        notes: input.notes ?? item.notes,
      }).where(eq(inventoryItems.id, input.itemId));
      await getDb().update(products).set({ quantity: input.actualQty }).where(eq(products.id, item.productId));
      return { success: true, difference: diff };
    }),

  complete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const items = await getDb().select().from(inventoryItems).where(eq(inventoryItems.inventoryId, input.id));
      for (const item of items) {
        await getDb().update(products).set({ quantity: item.actualQty }).where(eq(products.id, item.productId));
      }
      await getDb().update(inventoryCounts).set({ status: "completed" }).where(eq(inventoryCounts.id, input.id));
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(inventoryItems).where(eq(inventoryItems.inventoryId, input.id));
      await getDb().delete(inventoryCounts).where(eq(inventoryCounts.id, input.id));
      return { success: true };
    }),

  getStats: publicQuery.query(async () => {
    const totalProducts = await getDb().select({ count: count() }).from(products).where(eq(products.isActive, true));
    const totalInventories = await getDb().select({ count: count() }).from(inventoryCounts);
    const completedInventories = await getDb().select({ count: count() }).from(inventoryCounts).where(eq(inventoryCounts.status, "completed"));
    return {
      totalProducts: totalProducts[0]?.count ?? 0,
      totalInventories: totalInventories[0]?.count ?? 0,
      completedInventories: completedInventories[0]?.count ?? 0,
    };
  }),
});
