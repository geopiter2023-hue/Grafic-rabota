
import { createConnection } from "mysql2/promise";

async function fix() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  // 1. Show duplicate count before
  const [before] = await conn.execute(`
    SELECT COUNT(*) as total, COUNT(DISTINCT CONCAT(employeeId, '-', workDate)) as unique_combos 
    FROM workSchedules
  `);
  console.log("Before cleanup:", before[0]);

  // 2. Delete all isWorking=0 records (they are noise from broken updates)
  const [del0] = await conn.execute("DELETE FROM workSchedules WHERE isWorking = 0");
  console.log("Deleted isWorking=0 rows:", del0.affectedRows);

  // 3. For remaining duplicates (same employee+date), keep only the one with MAX(id)
  const [delDup] = await conn.execute(`
    DELETE ws1 FROM workSchedules ws1
    INNER JOIN workSchedules ws2 
      ON ws1.employeeId = ws2.employeeId 
      AND ws1.workDate = ws2.workDate 
      AND ws1.id < ws2.id
  `);
  console.log("Deleted duplicate rows:", delDup.affectedRows);

  // 4. After cleanup
  const [after] = await conn.execute(`
    SELECT COUNT(*) as total, COUNT(DISTINCT CONCAT(employeeId, '-', workDate)) as unique_combos 
    FROM workSchedules
  `);
  console.log("After cleanup:", after[0]);

  // 5. Check current state
  const [rows] = await conn.execute("SELECT id, employeeId, workDate, isWorking FROM workSchedules ORDER BY employeeId, workDate LIMIT 30");
  console.table(rows);

  await conn.end();
}

fix().catch(console.error);
