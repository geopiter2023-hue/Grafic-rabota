
import { createConnection } from "mysql2/promise";

async function addIndex() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  try {
    await conn.execute("CREATE UNIQUE INDEX workSchedules_employee_date_unique ON workSchedules(employeeId, workDate)");
    console.log("Unique index created!");
  } catch(e) {
    console.log("Index may already exist:", e.message);
  }

  await conn.end();
}

addIndex().catch(console.error);
