
import { createConnection } from "mysql2/promise";

async function check() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  const [rows] = await conn.execute("SELECT id, employeeId, workDate, HEX(workDate) as hex, isWorking FROM workSchedules ORDER BY employeeId, workDate LIMIT 50");
  console.log("=== workSchedules (all data) ===");
  console.table(rows);

  const [employees] = await conn.execute("SELECT id, name FROM employees");
  console.log("\n=== employees ===");
  console.table(employees);

  await conn.end();
}

check().catch(console.error);
