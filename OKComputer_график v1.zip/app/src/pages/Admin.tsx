import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "react-router";
import {
  ArrowLeft,
  Users,
  DollarSign,
  Briefcase,
  Wallet,
  BarChart3,
  Trash2,
  Plus,
  Package,
  ClipboardCheck,
} from "lucide-react";
import { toast } from "sonner";

export default function AdminPage() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true });
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [newEmpName, setNewEmpName] = useState("");
  const [newEmpSalary, setNewEmpSalary] = useState("2300");
  const [newEmpRate, setNewEmpRate] = useState("3");

  const { data: dashboard } = trpc.analytics.getDashboard.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const { data: revenueByEmployee } = trpc.analytics.getRevenueByEmployee.useQuery(
    { year, month },
    { enabled: user?.role === "admin" }
  );

  const { data: employees, refetch: refetchEmployees } = trpc.employee.list.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const { data: allTransactions } = trpc.analytics.getAllTransactions.useQuery(
    {
      start: `${year}-${String(month).padStart(2, "0")}-01`,
      end: `${year}-${String(month).padStart(2, "0")}-31`,
    },
    { enabled: user?.role === "admin" }
  );

  const { data: cashFlow } = trpc.analytics.getCashFlow.useQuery(
    {
      start: `${year}-${String(month).padStart(2, "0")}-01`,
      end: `${year}-${String(month).padStart(2, "0")}-31`,
    },
    { enabled: user?.role === "admin" }
  );

  const createEmp = trpc.employee.create.useMutation({
    onSuccess: () => {
      refetchEmployees();
      setNewEmpName("");
      setNewEmpSalary("2300");
      setNewEmpRate("3");
      toast.success("Сотрудник добавлен");
    },
  });

  const deleteEmp = trpc.employee.delete.useMutation({
    onSuccess: () => {
      refetchEmployees();
      toast.success("Сотрудник удален");
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-slate-500">Загрузка...</p>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-500 mb-4">Доступ запрещен. Требуется роль администратора.</p>
          <Link to="/">
            <Button variant="outline">На главную</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <header className="border-b bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/">
              <Button variant="ghost" size="sm" className="gap-1">
                <ArrowLeft className="w-4 h-4" />
                Назад
              </Button>
            </Link>
            <Link to="/products">
              <Button variant="outline" size="sm" className="gap-1">
                <Package className="w-4 h-4" />
                Товары
              </Button>
            </Link>
            <Link to="/inventory">
              <Button variant="outline" size="sm" className="gap-1">
                <ClipboardCheck className="w-4 h-4" />
                Инвентаризация
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-indigo-600" />
              Админ-панель
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-indigo-600" />
                <div>
                  <p className="text-sm text-slate-500">Сотрудников</p>
                  <p className="text-2xl font-bold">{dashboard?.totalEmployees ?? 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Briefcase className="w-8 h-8 text-emerald-600" />
                <div>
                  <p className="text-sm text-slate-500">Отчетов</p>
                  <p className="text-2xl font-bold">{dashboard?.totalReports ?? 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <DollarSign className="w-8 h-8 text-amber-600" />
                <div>
                  <p className="text-sm text-slate-500">Общая выручка</p>
                  <p className="text-2xl font-bold">{(dashboard?.totalRevenue ?? 0).toFixed(0)} ₽</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Wallet className="w-8 h-8 text-rose-600" />
                <div>
                  <p className="text-sm text-slate-500">Выплачено зарплат</p>
                  <p className="text-2xl font-bold">{(dashboard?.totalSalaries ?? 0).toFixed(0)} ₽</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center gap-3 mb-4">
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 12 }).map((_, i) => (
                <SelectItem key={i + 1} value={String(i + 1)}>
                  {[
                    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
                  ][i]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="number"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
            className="w-28"
          />
        </div>

        <Tabs defaultValue="revenue" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="revenue">Выручка по сотрудникам</TabsTrigger>
            <TabsTrigger value="employees">Сотрудники</TabsTrigger>
            <TabsTrigger value="cash">Касса и транзакции</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue">
            <Card>
              <CardHeader>
                <CardTitle>Выручка и зарплата по сотрудникам</CardTitle>
              </CardHeader>
              <CardContent>
                {revenueByEmployee && revenueByEmployee.length > 0 ? (
                  <div className="space-y-3">
                    {revenueByEmployee.map((row) => {
                      const emp = employees?.find((e) => e.id === row.employeeId);
                      return (
                        <div
                          key={row.employeeId}
                          className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg"
                        >
                          <div>
                            <p className="font-semibold">{emp?.name ?? `ID: ${row.employeeId}`}</p>
                            <p className="text-xs text-slate-500">
                              {getMonthName(month)} {year}
                            </p>
                          </div>
                          <div className="text-right space-y-1">
                            <p className="text-sm">
                              Выручка: <span className="font-bold">{Number(row.totalRevenue ?? 0).toFixed(2)} ₽</span>
                            </p>
                            <p className="text-sm">
                              Комиссия: <span className="font-bold text-emerald-600">{Number(row.totalCommission ?? 0).toFixed(2)} ₽</span>
                            </p>
                            <p className="text-sm">
                              Зарплата: <span className="font-bold text-indigo-600">{Number(row.totalSalary ?? 0).toFixed(2)} ₽</span>
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-slate-400 text-center py-8">Нет данных за выбранный период</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="employees">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Добавить сотрудника</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label>Имя</Label>
                    <Input value={newEmpName} onChange={(e) => setNewEmpName(e.target.value)} placeholder="Имя продавца" />
                  </div>
                  <div>
                    <Label>Оклад (руб.)</Label>
                    <Input value={newEmpSalary} onChange={(e) => setNewEmpSalary(e.target.value)} type="number" />
                  </div>
                  <div>
                    <Label>Процент от выручки (%)</Label>
                    <Input value={newEmpRate} onChange={(e) => setNewEmpRate(e.target.value)} type="number" />
                  </div>
                  <Button
                    onClick={() =>
                      createEmp.mutate({
                        name: newEmpName,
                        baseSalary: newEmpSalary,
                        commissionRate: newEmpRate,
                      })
                    }
                    disabled={!newEmpName || createEmp.isPending}
                    className="w-full gap-1"
                  >
                    <Plus className="w-4 h-4" />
                    Добавить
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Список сотрудников</CardTitle>
                </CardHeader>
                <CardContent>
                  {employees && employees.length > 0 ? (
                    <div className="space-y-2">
                      {employees.map((emp) => (
                        <div key={emp.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                          <div>
                            <p className="font-medium">{emp.name}</p>
                            <p className="text-xs text-slate-500">
                              Оклад: {Number(emp.baseSalary).toFixed(0)} ₽ | Процент: {emp.commissionRate}%
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteEmp.mutate({ id: emp.id })}
                            disabled={deleteEmp.isPending}
                            className="text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-center py-8">Нет сотрудников</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="cash">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Поток кассы за {getMonthName(month)} {year}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-slate-600">Приход</span>
                    <span className="font-semibold text-emerald-600">+{(cashFlow?.income ?? 0).toFixed(2)} ₽</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-slate-600">Расход</span>
                    <span className="font-semibold text-red-600">-{(cashFlow?.expense ?? 0).toFixed(2)} ₽</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="font-bold">Баланс</span>
                    <span className="font-bold text-indigo-600">{(cashFlow?.balance ?? 0).toFixed(2)} ₽</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Транзакции</CardTitle>
                </CardHeader>
                <CardContent>
                  {allTransactions && allTransactions.length > 0 ? (
                    <div className="space-y-2">
                      {allTransactions.map((tx) => {
                        const emp = employees?.find((e) => e.id === tx.employeeId);
                        return (
                          <div
                            key={tx.id}
                            className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg"
                          >
                            <div>
                              <p className="font-medium">{tx.description}</p>
                              <p className="text-xs text-slate-500">
                                {emp?.name ?? `ID: ${tx.employeeId}`} |{" "}
                                {new Date(tx.transactionDate + "T00:00:00").toLocaleDateString("ru-RU")}
                              </p>
                            </div>
                            <span
                              className={`font-bold ${tx.type === "income" ? "text-emerald-600" : "text-red-600"}`}
                            >
                              {tx.type === "income" ? "+" : "-"}
                              {Number(tx.amount).toFixed(2)} ₽
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-center py-8">Нет транзакций за период</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function getMonthName(month: number) {
  const names = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
  ];
  return names[month - 1];
}
