import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router";
import { ClipboardCheck, Plus, ArrowLeft, Check, Trash2, Package } from "lucide-react";
import { toast } from "sonner";

export default function InventoryPage() {
  const { user } = useAuth();
  const [selectedInventoryId, setSelectedInventoryId] = useState<number | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: employees } = trpc.employee.list.useQuery();
  const { data: inventories } = trpc.inventory.list.useQuery();
  const { data: products } = trpc.product.list.useQuery();

  const { data: selectedInventory } = trpc.inventory.getById.useQuery(
    { id: selectedInventoryId ?? 0 },
    { enabled: !!selectedInventoryId }
  );

  const createInventory = trpc.inventory.create.useMutation({
    onSuccess: (data) => {
      utils.inventory.list.invalidate();
      setSelectedInventoryId(data.id);
      toast.success("Инвентаризация создана");
    },
  });

  const updateItem = trpc.inventory.updateItem.useMutation({
    onSuccess: () => {
      utils.inventory.getById.invalidate();
      utils.product.list.invalidate();
    },
  });

  const completeInventory = trpc.inventory.complete.useMutation({
    onSuccess: () => {
      utils.inventory.list.invalidate();
      utils.inventory.getById.invalidate();
      utils.product.list.invalidate();
      toast.success("Инвентаризация завершена! Остатки обновлены.");
    },
  });

  const deleteInventory = trpc.inventory.delete.useMutation({
    onSuccess: () => {
      utils.inventory.list.invalidate();
      setSelectedInventoryId(null);
      toast.success("Инвентаризация удалена");
    },
  });

  const [actualQtyMap, setActualQtyMap] = useState<Record<number, string>>({});

  const today = new Date().toISOString().slice(0, 10);

  const handleQtyChange = (itemId: number, value: string) => {
    setActualQtyMap((prev) => ({ ...prev, [itemId]: value }));
  };

  const handleSaveItem = (itemId: number, _currentActual: number) => {
    const val = actualQtyMap[itemId];
    if (val === undefined) return;
    updateItem.mutate({ itemId, actualQty: Number(val) || 0 });
  };

  const totalDiff = selectedInventory?.items?.reduce(
    (sum, item) => sum + Math.abs(item.difference), 0
  ) ?? 0;

  const isAdmin = user?.role === "admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/">
              <Button variant="ghost" size="sm"><ArrowLeft className="w-4 h-4" /></Button>
            </Link>
            <ClipboardCheck className="w-6 h-6 text-indigo-600" />
            <h1 className="text-xl font-bold">Инвентаризация</h1>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Package className="w-8 h-8 text-indigo-600" />
                <div>
                  <p className="text-sm text-slate-500">Товаров в базе</p>
                  <p className="text-2xl font-bold">{products?.length ?? 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <ClipboardCheck className="w-8 h-8 text-emerald-600" />
                <div>
                  <p className="text-sm text-slate-500">Всего инвентаризаций</p>
                  <p className="text-2xl font-bold">{inventories?.length ?? 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Check className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="text-sm text-slate-500">Завершено</p>
                  <p className="text-2xl font-bold">
                    {inventories?.filter((i) => i.status === "completed").length ?? 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-5">
          {/* Left sidebar - list of inventories */}
          <div className="md:col-span-2 space-y-4">
            {/* Create new */}
            <Card>
              <CardHeader><CardTitle className="text-sm">Новая инвентаризация</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label>Продавец</Label>
                  <Select value={String(selectedEmployeeId ?? "")} onValueChange={(v) => setSelectedEmployeeId(Number(v))}>
                    <SelectTrigger><SelectValue placeholder="Выберите продавца" /></SelectTrigger>
                    <SelectContent>
                      {employees?.map((e) => (
                        <SelectItem key={e.id} value={String(e.id)}>{e.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={() => {
                    if (!selectedEmployeeId) { toast.error("Выберите продавца"); return; }
                    createInventory.mutate({ employeeId: selectedEmployeeId, countDate: today });
                  }}
                  disabled={createInventory.isPending}
                  className="w-full gap-1"
                >
                  <Plus className="w-4 h-4" />
                  Создать
                </Button>
              </CardContent>
            </Card>

            {/* List */}
            <Card>
              <CardHeader><CardTitle className="text-sm">Список инвентаризаций</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {inventories && inventories.length > 0 ? (
                  inventories.map((inv) => (
                    <button
                      key={inv.id}
                      onClick={() => setSelectedInventoryId(inv.id)}
                      className={
                        "w-full text-left p-3 rounded-lg border transition-colors " +
                        (selectedInventoryId === inv.id
                          ? "bg-indigo-50 border-indigo-300"
                          : "bg-white border-slate-200 hover:bg-slate-50")
                      }
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">#{inv.id} — {inv.countDate}</span>
                        <span className={
                          "text-xs px-2 py-0.5 rounded-full " +
                          (inv.status === "completed" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700")
                        }>
                          {inv.status === "completed" ? "Завершена" : "Черновик"}
                        </span>
                      </div>
                    </button>
                  ))
                ) : (
                  <p className="text-slate-400 text-center py-4">Нет инвентаризаций</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right - inventory detail */}
          <div className="md:col-span-3">
            {selectedInventory ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Инвентаризация #{selectedInventory.id}</CardTitle>
                      <p className="text-sm text-slate-500 mt-1">
                        Дата: {selectedInventory.countDate} |
                        Статус: {selectedInventory.status === "completed" ? "Завершена" : "Черновик"} |
                        Расхождений: <span className={totalDiff > 0 ? "text-red-600 font-bold" : "text-emerald-600 font-bold"}>{totalDiff} ед.</span>
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {selectedInventory.status === "draft" && (
                        <Button
                          onClick={() => completeInventory.mutate({ id: selectedInventory.id })}
                          disabled={completeInventory.isPending}
                          className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                        >
                          <Check className="w-4 h-4" />
                          Завершить
                        </Button>
                      )}
                      {isAdmin && (
                        <Button variant="ghost" size="sm" onClick={() => deleteInventory.mutate({ id: selectedInventory.id })}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {selectedInventory.items && selectedInventory.items.length > 0 ? (
                    <div className="space-y-2">
                      <div className="grid grid-cols-12 gap-2 text-xs font-bold text-slate-500 pb-2 border-b">
                        <div className="col-span-4">Товар</div>
                        <div className="col-span-2 text-center">Учетное</div>
                        <div className="col-span-2 text-center">Фактическое</div>
                        <div className="col-span-2 text-center">Разница</div>
                        <div className="col-span-2"></div>
                      </div>
                      {selectedInventory.items.map((item) => {
                        const product = products?.find((p) => p.id === item.productId);
                        const diff = item.difference;
                        const inputVal = actualQtyMap[item.id] ?? String(item.actualQty);
                        return (
                          <div key={item.id} className="grid grid-cols-12 gap-2 items-center py-2 border-b border-slate-100">
                            <div className="col-span-4">
                              <p className="font-medium text-sm">{product?.name ?? `ID:${item.productId}`}</p>
                              <p className="text-xs text-slate-400">{product?.sku ?? ""}</p>
                            </div>
                            <div className="col-span-2 text-center text-sm">{item.expectedQty} {product?.unit}</div>
                            <div className="col-span-2">
                              <Input
                                type="number"
                                value={inputVal}
                                onChange={(e) => handleQtyChange(item.id, e.target.value)}
                                disabled={selectedInventory.status === "completed"}
                                className="h-8 text-center text-sm"
                              />
                            </div>
                            <div className={"col-span-2 text-center text-sm font-bold " + (diff < 0 ? "text-red-600" : diff > 0 ? "text-emerald-600" : "text-slate-400")}>
                              {diff > 0 ? "+" : ""}{diff} {product?.unit}
                            </div>
                            <div className="col-span-2">
                              {selectedInventory.status === "draft" && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleSaveItem(item.id, item.actualQty)}
                                  disabled={updateItem.isPending}
                                  className="h-8 text-xs w-full"
                                >
                                  Сохранить
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-center py-8">Нет товаров в инвентаризации</p>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <ClipboardCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-400">Выберите или создайте инвентаризацию</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
