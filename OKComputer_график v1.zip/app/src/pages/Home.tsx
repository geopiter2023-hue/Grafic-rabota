import { useState, useEffect, useMemo, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router";
import {
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  DollarSign,
  Wallet,
  User,
  LogOut,
  ShieldCheck,
  Users,
  Download,
  Package,
  ClipboardCheck,
} from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month, 0).getDate();
}

function getMonthName(month: number) {
  const names = [
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
  ];
  return names[month - 1];
}

function formatDate(year: number, month: number, day: number) {
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function getWeekdayName(year: number, month: number, day: number) {
  const d = new Date(year, month - 1, day);
  const names = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
  return names[d.getDay()];
}

export default function HomePage() {
  const { user, isAuthenticated, logout } = useAuth();
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<number | null>(null);
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [selectedDate, setSelectedDate] = useState<string>(formatDate(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate()));
  const [activeTab, setActiveTab] = useState("schedule");
  const tableRef = useRef<HTMLDivElement>(null);

  const { data: employees } = trpc.employee.list.useQuery();

  useEffect(() => {
    if (employees && employees.length > 0 && !selectedEmployeeId) {
      setSelectedEmployeeId(employees[0].id);
    }
  }, [employees, selectedEmployeeId]);

  const { data: schedules, refetch: refetchSchedules } = trpc.schedule.listByMonth.useQuery(
    { year, month },
    { enabled: true }
  );

  const { data: workingDaysCount, refetch: refetchWorkingDays } = trpc.schedule.countWorkingDays.useQuery(
    { employeeId: selectedEmployeeId ?? 0, year, month },
    { enabled: !!selectedEmployeeId }
  );

  const { data: dayReport, refetch: refetchDayReport } = trpc.report.getByDate.useQuery(
    { employeeId: selectedEmployeeId ?? 0, date: selectedDate },
    { enabled: !!selectedEmployeeId }
  );

  const { data: cashBalance } = trpc.cash.getBalance.useQuery(
    { date: selectedDate },
    { enabled: !!selectedEmployeeId }
  );

  const { data: cashTxs, refetch: refetchCash } = trpc.cash.listByDateRange.useQuery(
    { start: selectedDate, end: selectedDate },
    { enabled: !!selectedEmployeeId }
  );

  const setDayMutation = trpc.schedule.setDay.useMutation({
    onSuccess: () => {
      refetchSchedules();
      refetchWorkingDays();
    },
  });

  const reportMutation = trpc.report.createOrUpdate.useMutation({
    onSuccess: () => {
      refetchDayReport();
      toast.success("Отчет сохранен");
    },
  });

  const cashMutation = trpc.cash.create.useMutation({
    onSuccess: () => {
      refetchCash();
    },
  });

  // Build lookup: employeeId -> dateStr -> isWorking (1 or 0)
  const scheduleMap = useMemo(() => {
    const map = new Map<number, Map<string, number>>();
    if (schedules) {
      for (const s of schedules) {
        const dateStr = typeof s.workDate === "string" ? s.workDate : String(s.workDate).slice(0, 10);
        if (!map.has(s.employeeId)) {
          map.set(s.employeeId, new Map());
        }
        map.get(s.employeeId)!.set(dateStr, s.isWorking ? 1 : 0);
      }
    }
    return map;
  }, [schedules]);

  const days = getDaysInMonth(year, month);

  const isWorkingDay = (empId: number, dateStr: string): boolean => {
    return (scheduleMap.get(empId)?.get(dateStr) ?? 0) === 1;
  };

  const handleToggleDay = (employeeId: number, dateStr: string) => {
    const current = isWorkingDay(employeeId, dateStr);
    setDayMutation.mutate({
      employeeId,
      workDate: dateStr,
      isWorking: !current,
    });
  };

  const [revenue, setRevenue] = useState("");
  const [cashStart, setCashStart] = useState("");
  const [cashEnd, setCashEnd] = useState("");
  const [notes, setNotes] = useState("");

  const [cashType, setCashType] = useState<"income" | "expense">("income");
  const [cashAmount, setCashAmount] = useState("");
  const [cashDesc, setCashDesc] = useState("");

  useEffect(() => {
    if (dayReport) {
      setRevenue(String(dayReport.revenue));
      setCashStart(String(dayReport.cashStart));
      setCashEnd(String(dayReport.cashEnd));
      setNotes(dayReport.notes ?? "");
    } else {
      setRevenue("");
      setCashStart("");
      setCashEnd("");
      setNotes("");
    }
  }, [dayReport]);

  const handleSaveReport = () => {
    if (!selectedEmployeeId || !revenue) return;
    reportMutation.mutate({
      employeeId: selectedEmployeeId,
      reportDate: selectedDate,
      revenue,
      cashStart: cashStart || undefined,
      cashEnd: cashEnd || undefined,
      notes: notes || undefined,
    });
  };

  const handleAddCashTx = () => {
    if (!selectedEmployeeId || !cashAmount || !cashDesc) return;
    cashMutation.mutate({
      employeeId: selectedEmployeeId,
      transactionDate: selectedDate,
      type: cashType,
      amount: cashAmount,
      description: cashDesc,
    });
    setCashAmount("");
    setCashDesc("");
  };

  const selectedEmployee = employees?.find((e) => e.id === selectedEmployeeId);
  const commission = selectedEmployee && revenue ? Number(revenue) * (Number(selectedEmployee.commissionRate) / 100) : 0;
  const salaryTotal = selectedEmployee ? Number(selectedEmployee.baseSalary) + commission : 0;

  const workingDaysPerEmployee = useMemo(() => {
    const counts = new Map<number, number>();
    if (schedules) {
      for (const s of schedules) {
        if (s.isWorking) {
          counts.set(s.employeeId, (counts.get(s.employeeId) || 0) + 1);
        }
      }
    }
    return counts;
  }, [schedules]);

  // PDF Export using html2canvas (supports Cyrillic)
  const handleExportPDF = async () => {
    if (!employees || employees.length === 0) {
      toast.error("Нет данных для экспорта");
      return;
    }
    if (!tableRef.current) {
      toast.error("Таблица не найдена");
      return;
    }

    try {
      toast.info("Генерация PDF...");
      const canvas = await html2canvas(tableRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
      });

      const imgData = canvas.toDataURL("image/png");
      const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const imgWidth = pageWidth - margin * 2;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      doc.setFontSize(14);
      const title = `График работы — ${getMonthName(month)} ${year}`;
      doc.text(title, margin, margin + 10);

      const yPos = margin + 20;
      if (imgHeight > pageHeight - yPos - margin) {
        const scaledHeight = pageHeight - yPos - margin;
        const scaledWidth = (canvas.width * scaledHeight) / canvas.height;
        const xOffset = margin + (imgWidth - scaledWidth) / 2;
        doc.addImage(imgData, "PNG", xOffset, yPos, scaledWidth, scaledHeight);
      } else {
        doc.addImage(imgData, "PNG", margin, yPos, imgWidth, imgHeight);
      }

      doc.save(`График_${getMonthName(month)}_${year}.pdf`);
      toast.success("PDF скачан!");
    } catch (e) {
      console.error("PDF export error:", e);
      toast.error("Ошибка при создании PDF");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-2 md:px-4 py-2 md:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5 md:w-6 md:h-6 text-indigo-600" />
            <h1 className="text-sm md:text-xl font-bold text-slate-900 whitespace-nowrap">График</h1>
          </div>
          <div className="flex items-center gap-1 md:gap-2">
            <Link to="/products">
              <Button variant="outline" size="sm" className="gap-1 px-1.5 md:px-3">
                <Package className="w-4 h-4" />
                <span className="hidden md:inline">Товары</span>
              </Button>
            </Link>
            <Link to="/inventory">
              <Button variant="outline" size="sm" className="gap-1 px-1.5 md:px-3">
                <ClipboardCheck className="w-4 h-4" />
                <span className="hidden md:inline">Инвентарь</span>
              </Button>
            </Link>
            {isAuthenticated && user?.role === "admin" && (
              <Link to="/admin">
                <Button variant="outline" size="sm" className="gap-1 px-1.5 md:px-3">
                  <ShieldCheck className="w-4 h-4" />
                  <span className="hidden md:inline">Админ</span>
                </Button>
              </Link>
            )}
            {isAuthenticated ? (
              <div className="flex items-center gap-1 md:gap-2">
                <span className="hidden md:flex text-sm text-slate-600 items-center gap-1">
                  <User className="w-4 h-4" />
                  {user?.name ?? "Админ"}
                </span>
                <Button variant="ghost" size="sm" onClick={logout} className="px-1.5 md:px-3 gap-1">
                  <LogOut className="w-4 h-4" />
                  <span className="hidden md:inline">Выйти</span>
                </Button>
              </div>
            ) : (
              <Link to="/login">
                <Button size="sm" className="px-2 md:px-3">Войти</Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {(!employees || employees.length === 0) && (
          <Card className="mb-6 border-amber-300 bg-amber-50">
            <CardContent className="py-4">
              <div className="flex items-center gap-3">
                <Users className="w-6 h-6 text-amber-600" />
                <div>
                  <p className="font-semibold text-amber-800">Нет продавцов в системе</p>
                  <p className="text-sm text-amber-700">
                    {isAuthenticated && user?.role === "admin" ? (
                      <Link to="/admin" className="underline font-medium">Добавьте продавцов в админ-панели</Link>
                    ) : (
                      "Администратор должен добавить продавцов в админ-панели"
                    )}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4 flex-wrap h-auto">
            <TabsTrigger value="schedule" className="gap-1">
              <Users className="w-4 h-4" />
              Общий график
            </TabsTrigger>
            <TabsTrigger value="personal" className="gap-1">
              <CalendarDays className="w-4 h-4" />
              Личный кабинет
            </TabsTrigger>
            <TabsTrigger value="cash" className="gap-1">
              <Wallet className="w-4 h-4" />
              Касса
            </TabsTrigger>
          </TabsList>

          {/* ====== SHARED SCHEDULE TABLE ====== */}
          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <CardTitle>График работы на {getMonthName(month)} {year}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">
                      Нажмите на ячейку — отметить рабочий день. Нажмите ещё раз — снять.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => { if (month === 1) { setMonth(12); setYear(y => y - 1); } else setMonth(m => m - 1); }}>
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <span className="text-sm font-medium min-w-[120px] text-center]">{getMonthName(month)} {year}</span>
                    <Button variant="outline" size="sm" onClick={() => { if (month === 12) { setMonth(1); setYear(y => y + 1); } else setMonth(m => m + 1); }}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleExportPDF} className="gap-1 ml-2">
                      <Download className="w-4 h-4" />
                      PDF
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-2 md:p-6">
                {employees && employees.length > 0 ? (
                  <div className="overflow-x-auto" ref={tableRef}>
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b-2 border-slate-300">
                          <th className="text-left p-2 text-xs font-bold text-slate-400 sticky left-0 bg-white z-10 min-w-[60px]">Дата</th>
                          {employees.map((emp) => (
                            <th key={emp.id} className="text-center p-2 min-w-[70px]">
                              <div className="text-xs font-bold text-slate-700">{emp.name}</div>
                              <div className="text-[10px] font-normal text-slate-400">
                                {workingDaysPerEmployee.get(emp.id) ?? 0} дн.
                              </div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {Array.from({ length: days }).map((_, i) => {
                          const day = i + 1;
                          const dateStr = formatDate(year, month, day);
                          const isToday = dateStr === formatDate(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate());
                          const isWeekend = [0, 6].includes(new Date(year, month - 1, day).getDay());
                          return (
                            <tr
                              key={day}
                              className={"border-b border-slate-100" + (isToday ? " bg-blue-50" : "")}
                            >
                              <td className={"p-2 text-xs font-medium sticky left-0 bg-white z-10" + (isToday ? " text-blue-600 font-bold" : "") + (isWeekend ? " text-slate-400" : " text-slate-600")}>
                                <span>{day}</span>
                                <span className="text-[10px] uppercase ml-1 opacity-60">{getWeekdayName(year, month, day)}</span>
                              </td>
                              {employees.map((emp) => {
                                const working = isWorkingDay(emp.id, dateStr);
                                return (
                                  <td key={emp.id} className="p-1">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        handleToggleDay(emp.id, dateStr);
                                        setSelectedDate(dateStr);
                                        setSelectedEmployeeId(emp.id);
                                      }}
                                      className={
                                        "w-full h-11 rounded-lg flex items-center justify-center text-sm font-bold border-2 select-none transition-colors" +
                                        (working
                                          ? " bg-slate-700 text-white border-slate-700"
                                          : " bg-white text-slate-300 border-slate-200 hover:border-slate-400")
                                      }
                                    >
                                      {working ? "Р" : ""}
                                    </button>
                                  </td>
                                );
                              })}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-400">Сначала добавьте продавцов в админ-панели</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ====== PERSONAL CALENDAR ====== */}
          <TabsContent value="personal">
            <div className="mb-4">
              <Select value={String(selectedEmployeeId ?? "")} onValueChange={(v) => setSelectedEmployeeId(Number(v))}>
                <SelectTrigger className="w-72">
                  <SelectValue placeholder="Выберите продавца" />
                </SelectTrigger>
                <SelectContent>
                  {employees?.map((emp) => (
                    <SelectItem key={emp.id} value={String(emp.id)}>{emp.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Календарь — {selectedEmployee?.name ?? "..."}</CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="outline" size="sm" onClick={() => { if (month === 1) { setMonth(12); setYear(y => y - 1); } else setMonth(m => m - 1); }}>
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <span className="text-sm font-medium min-w-[120px] text-center">{getMonthName(month)} {year}</span>
                    <Button variant="outline" size="sm" onClick={() => { if (month === 12) { setMonth(1); setYear(y => y + 1); } else setMonth(m => m + 1); }}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-slate-500 mt-1">
                    Рабочих дней: <span className="font-bold text-indigo-600 text-lg">{workingDaysCount ?? 0}</span>
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((d) => (
                      <div key={d} className="text-center text-xs font-medium text-slate-500 py-1">{d}</div>
                    ))}
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {(() => {
                      const firstDayWeekday = new Date(year, month - 1, 1).getDay();
                      const adjustedFirstDay = firstDayWeekday === 0 ? 6 : firstDayWeekday - 1;
                      return Array.from({ length: adjustedFirstDay }).map((_, i) => (
                        <div key={`e-${i}`} />
                      ));
                    })()}
                    {Array.from({ length: days }).map((_, i) => {
                      const day = i + 1;
                      const dateStr = formatDate(year, month, day);
                      const working = selectedEmployeeId ? isWorkingDay(selectedEmployeeId, dateStr) : false;
                      const selected = dateStr === selectedDate;
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            setSelectedDate(dateStr);
                            if (selectedEmployeeId) handleToggleDay(selectedEmployeeId, dateStr);
                          }}
                          className={
                            "h-12 rounded-lg border-2 text-sm font-bold flex items-center justify-center select-none transition-colors" +
                            (working && selected
                              ? " bg-slate-700 text-white border-orange-500 ring-2 ring-orange-500"
                              : working
                              ? " bg-slate-700 text-white border-slate-700"
                              : selected
                              ? " bg-white text-slate-700 border-orange-500"
                              : " bg-white text-slate-700 border-slate-200 hover:border-slate-400")
                          }
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><span className="w-4 h-4 bg-slate-700 rounded inline-block"/> Рабочий</span>
                    <span className="flex items-center gap-1"><span className="w-4 h-4 bg-white border-2 border-orange-500 rounded inline-block"/> Выбран</span>
                    <span className="flex items-center gap-1"><span className="w-4 h-4 bg-white border border-slate-200 rounded inline-block"/> Выходной</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Отчет за {selectedDate}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Выручка (руб.)</Label>
                    <Input type="number" value={revenue} onChange={(e) => setRevenue(e.target.value)} placeholder="0.00" />
                  </div>
                  <div className="p-3 bg-slate-100 rounded-lg space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Оклад</span>
                      <span className="font-medium">{selectedEmployee ? Number(selectedEmployee.baseSalary).toFixed(2) : "2300.00"} ₽</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Комиссия ({selectedEmployee ? selectedEmployee.commissionRate : "3"}%)</span>
                      <span className="font-medium text-emerald-600">{commission.toFixed(2)} ₽</span>
                    </div>
                    <div className="flex justify-between text-base font-bold pt-1 border-t border-slate-300">
                      <span>Итого к выплате</span>
                      <span className="text-indigo-700">{salaryTotal.toFixed(2)} ₽</span>
                    </div>
                  </div>
                  <div>
                    <Label>Остаток в кассе на начало</Label>
                    <Input type="number" value={cashStart} onChange={(e) => setCashStart(e.target.value)} placeholder="0.00" />
                  </div>
                  <div>
                    <Label>Остаток в кассе на конец</Label>
                    <Input type="number" value={cashEnd} onChange={(e) => setCashEnd(e.target.value)} placeholder="0.00" />
                  </div>
                  <div>
                    <Label>Примечания</Label>
                    <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="..." />
                  </div>
                  <Button onClick={handleSaveReport} disabled={reportMutation.isPending || !selectedEmployeeId} className="w-full">
                    <DollarSign className="w-4 h-4 mr-1" />
                    Сохранить отчет
                  </Button>

                  {dayReport && (
                    <div className="mt-2 p-3 bg-slate-50 rounded-lg text-sm space-y-1">
                      <p className="text-slate-500 font-medium">Сохранено:</p>
                      <p>Выручка: <span className="font-bold">{Number(dayReport.revenue).toFixed(2)} ₽</span></p>
                      <p>Комиссия: <span className="font-bold">{Number(dayReport.commission).toFixed(2)} ₽</span></p>
                      <p>Зарплата: <span className="font-bold">{Number(dayReport.salaryTotal).toFixed(2)} ₽</span></p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ====== CASH ====== */}
          <TabsContent value="cash">
            <div className="mb-4">
              <Select value={String(selectedEmployeeId ?? "")} onValueChange={(v) => setSelectedEmployeeId(Number(v))}>
                <SelectTrigger className="w-72"><SelectValue placeholder="Выберите продавца"/></SelectTrigger>
                <SelectContent>
                  {employees?.map((emp) => (
                    <SelectItem key={emp.id} value={String(emp.id)}>{emp.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader><CardTitle>Баланс кассы на {selectedDate}</CardTitle></CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-indigo-700">{(cashBalance?.balance ?? 0).toFixed(2)} ₽</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle>Новая транзакция</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label>Тип</Label>
                    <Select value={cashType} onValueChange={(v) => setCashType(v as "income" | "expense")}>
                      <SelectTrigger><SelectValue/></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="income">Приход</SelectItem>
                        <SelectItem value="expense">Расход</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>Сумма</Label><Input type="number" value={cashAmount} onChange={(e) => setCashAmount(e.target.value)} placeholder="0.00"/></div>
                  <div><Label>Описание</Label><Input value={cashDesc} onChange={(e) => setCashDesc(e.target.value)} placeholder="Например: инкассация"/></div>
                  <Button onClick={handleAddCashTx} disabled={cashMutation.isPending || !selectedEmployeeId} className="w-full">Добавить</Button>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader><CardTitle>Транзакции за {selectedDate}</CardTitle></CardHeader>
                <CardContent>
                  {cashTxs && cashTxs.length > 0 ? (
                    <div className="space-y-2">
                      {cashTxs.map((tx) => (
                        <div key={tx.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                          <div>
                            <p className="font-medium">{tx.description}</p>
                            <p className="text-xs text-slate-500">{tx.transactionDate}</p>
                          </div>
                          <span className={"font-bold " + (tx.type === "income" ? "text-emerald-600" : "text-red-600")}>
                            {tx.type === "income" ? "+" : "-"}{Number(tx.amount).toFixed(2)} ₽
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-center py-8">Нет транзакций</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
