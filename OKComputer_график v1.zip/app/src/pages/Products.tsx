import { useState, useRef, useEffect, useCallback } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router";
import { Package, Plus, Trash2, ArrowLeft, Search, Edit3, Upload, ScanBarcode, Percent } from "lucide-react";
import { toast } from "sonner";
import Papa from "papaparse";
import * as XLSX from "xlsx";

export default function ProductsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("list");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showScanner, setShowScanner] = useState(false);
  const [importData, setImportData] = useState<Array<Record<string, string>> | null>(null);
  const [importFileName, setImportFileName] = useState("");

  // Scanner state
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<number | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formSku, setFormSku] = useState("");
  const [formBarcode, setFormBarcode] = useState("");
  const [formCategory, setFormCategory] = useState("Общее");
  const [formCostPrice, setFormCostPrice] = useState("");
  const [formPrice, setFormPrice] = useState("");
  const [formMarkup, setFormMarkup] = useState("0");
  const [formQty, setFormQty] = useState("");
  const [formMinQty, setFormMinQty] = useState("5");
  const [formUnit, setFormUnit] = useState("шт");

  const utils = trpc.useUtils();
  const { data: products } = trpc.product.list.useQuery();
  const { data: searchResults } = trpc.product.search.useQuery(
    { query: search },
    { enabled: search.length > 0 }
  );

  const createProduct = trpc.product.create.useMutation({
    onSuccess: () => { utils.product.list.invalidate(); resetForm(); toast.success("Товар добавлен"); setActiveTab("list"); },
  });

  const updateProduct = trpc.product.update.useMutation({
    onSuccess: () => { utils.product.list.invalidate(); resetForm(); setEditingId(null); toast.success("Товар обновлен"); setActiveTab("list"); },
  });

  const deleteProduct = trpc.product.delete.useMutation({
    onSuccess: () => { utils.product.list.invalidate(); toast.success("Товар удален"); },
  });

  const bulkImport = trpc.product.bulkImport.useMutation({
    onSuccess: (data) => { utils.product.list.invalidate(); setImportData(null); setImportFileName(""); toast.success(`Импортировано ${data.imported} товаров`); },
  });

  const applyMarkup = trpc.product.applyMarkup.useMutation({
    onSuccess: (data) => { utils.product.list.invalidate(); setSelectedIds(new Set()); toast.success(`Наценка применена к ${data.updated} товарам`); },
  });

  const resetForm = () => {
    setFormName(""); setFormSku(""); setFormBarcode(""); setFormCategory("Общее");
    setFormCostPrice(""); setFormPrice(""); setFormMarkup("0");
    setFormQty(""); setFormMinQty("5"); setFormUnit("шт");
  };

  const startEdit = (product: NonNullable<typeof products>[0]) => {
    setEditingId(product.id);
    setFormName(product.name);
    setFormSku(product.sku ?? "");
    setFormBarcode(product.barcode ?? "");
    setFormCategory(product.category);
    setFormCostPrice(String(product.costPrice ?? ""));
    setFormPrice(String(product.price));
    setFormMarkup(String(product.markupPercent ?? "0"));
    setFormQty(String(product.quantity));
    setFormMinQty(String(product.minQuantity));
    setFormUnit(product.unit);
    setActiveTab("form");
  };

  const calcPriceFromMarkup = () => {
    const cost = Number(formCostPrice);
    const markup = Number(formMarkup);
    if (cost > 0 && markup >= 0) {
      setFormPrice((cost * (1 + markup / 100)).toFixed(2));
    }
  };

  const handleSave = () => {
    if (!formName) { toast.error("Введите название"); return; }
    let price = formPrice;
    const cost = Number(formCostPrice);
    const markup = Number(formMarkup);
    if (cost > 0 && markup >= 0) {
      price = (cost * (1 + markup / 100)).toFixed(2);
    }
    if (editingId) {
      updateProduct.mutate({ id: editingId, name: formName, sku: formSku || undefined, barcode: formBarcode || undefined, category: formCategory, costPrice: formCostPrice || undefined, price: price || undefined, markupPercent: formMarkup || undefined, quantity: formQty ? Number(formQty) : undefined, minQuantity: formMinQty ? Number(formMinQty) : undefined, unit: formUnit });
    } else {
      createProduct.mutate({ name: formName, sku: formSku || undefined, barcode: formBarcode || undefined, category: formCategory, costPrice: formCostPrice || undefined, price: price || undefined, markupPercent: formMarkup || undefined, quantity: formQty ? Number(formQty) : undefined, minQuantity: formMinQty ? Number(formMinQty) : undefined, unit: formUnit });
    }
  };

  // ====== Simple barcode scanner ======
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 640 }, height: { ideal: 480 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      // Start scanning loop
      const BarcodeDetectorAPI = (window as unknown as Record<string, unknown>).BarcodeDetector as
        new (opts: { formats: string[] }) => { detect: (image: HTMLVideoElement) => Promise<Array<{ rawValue: string }>> } | undefined;
      if (BarcodeDetectorAPI) {
        const detector = new BarcodeDetectorAPI({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "qr_code"] });
        if (!detector) return;
        scanIntervalRef.current = window.setInterval(async () => {
          if (!videoRef.current) return;
          try {
            const results = await detector.detect(videoRef.current);
            if (results.length > 0) {
              const code = results[0].rawValue;
              setSearch(code);
              toast.success(`Найден: ${code}`);
              stopCamera();
            }
          } catch { /* ignore detection errors */ }
        }, 500);
      } else {
        // Fallback: no BarcodeDetector API
        toast.info("Введите штрихкод вручную");
      }
    } catch {
      toast.error("Нет доступа к камере");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setShowScanner(false);
  }, []);

  useEffect(() => {
    return () => stopCamera();
  }, [stopCamera]);

  // ====== File Import (CSV + XLSX) ======
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFileName(file.name);
    const ext = file.name.split(".").pop()?.toLowerCase();

    if (ext === "csv" || ext === "txt") {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        encoding: "utf-8",
        complete: (results) => setImportData(results.data as Array<Record<string, string>>),
        error: () => toast.error("Ошибка чтения CSV"),
      });
    } else if (ext === "xlsx" || ext === "xls") {
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const data = new Uint8Array(ev.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const json = XLSX.utils.sheet_to_json<Record<string, string>>(firstSheet, { header: 1 });
          if (json.length > 1) {
            const headers = json[0] as unknown as string[];
            const rows = json.slice(1).map((row) => {
              const obj: Record<string, string> = {};
              (row as unknown as string[]).forEach((cell, i) => { obj[String(headers[i] ?? `col${i}`)] = String(cell ?? ""); });
              return obj;
            });
            setImportData(rows);
          }
        } catch {
          toast.error("Ошибка чтения Excel");
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      toast.error("Поддерживаются CSV и XLSX файлы");
    }
  };

  const handleImport = () => {
    if (!importData) return;
    const items = importData.map((row) => {
      const getVal = (...keys: string[]) => {
        for (const k of keys) { if (row[k] !== undefined && row[k] !== "") return row[k]; }
        return undefined;
      };
      return {
        name: getVal("name", "Название", "название", "товар", "Товар", "product") ?? "",
        sku: getVal("sku", "Артикул", "артикул", "SKU", "sku"),
        barcode: getVal("barcode", "Штрихкод", "штрихкод", "Баркод", "баркод", "EAN", "ean", "Код", "код"),
        category: getVal("category", "Категория", "категория", "Группа", "группа") ?? "Общее",
        costPrice: getVal("costPrice", "Закупочная", "закупочная", "себестоимость", "Себестоимость", "cost", "Cost"),
        price: getVal("price", "Цена", "цена", "розница", "Розница", "Price"),
        markupPercent: getVal("markupPercent", "Наценка%", "наценка", "Наценка", " markup", "Markup"),
        quantity: Number(getVal("quantity", "Количество", "количество", "остаток", "Остаток", "Кол-во", "кол-во", "Qty") ?? 0),
        unit: getVal("unit", "Единица", "единица", "Ед.", "ед.") ?? "шт",
      };
    }).filter((i) => i.name);
    if (items.length === 0) { toast.error("Не найдено товаров в файле"); return; }
    bulkImport.mutate({ items });
  };

  // Markup
  const toggleSelect = (id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleApplyMarkup = () => {
    if (selectedIds.size === 0) { toast.error("Выберите товары"); return; }
    const markup = Number(prompt("Наценка (%):", "30"));
    if (isNaN(markup) || markup < 0) return;
    applyMarkup.mutate({ ids: Array.from(selectedIds), markupPercent: markup });
  };

  // Filter
  const displayProducts = search.length > 0 ? (searchResults ?? []) : (products ?? []);
  const byCategory = new Map<string, typeof displayProducts>();
  displayProducts.forEach((p) => {
    if (!byCategory.has(p.category)) byCategory.set(p.category, []);
    byCategory.get(p.category)!.push(p);
  });

  const isAdmin = user?.role === "admin";

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-2 md:px-4 py-2 md:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 md:gap-3">
            <Link to="/"><Button variant="ghost" size="sm" className="px-1.5 md:px-3"><ArrowLeft className="w-4 h-4" /></Button></Link>
            <Package className="w-5 h-5 md:w-6 md:h-6 text-indigo-600" />
            <h1 className="text-sm md:text-xl font-bold whitespace-nowrap">Товары</h1>
          </div>
          <div className="flex items-center gap-1 md:gap-2">
            {isAdmin && selectedIds.size > 0 && (
              <Button variant="outline" size="sm" onClick={handleApplyMarkup} className="gap-1 px-1.5 md:px-3 bg-amber-50 border-amber-300 text-xs md:text-sm">
                <Percent className="w-3 h-3 md:w-4 md:h-4" />
                <span className="hidden md:inline">Наценка ({selectedIds.size})</span>
                <span className="md:hidden">+{selectedIds.size}</span>
              </Button>
            )}
            <Link to="/inventory">
              <Button variant="outline" size="sm" className="gap-1 px-1.5 md:px-3 text-xs md:text-sm">
                <ArrowLeft className="w-3 h-3 md:w-4 md:h-4 rotate-180" />
                <span className="hidden md:inline">Инвентарь</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-2 md:px-4 py-4 md:py-6">
        {/* Simple scanner overlay */}
        {showScanner && (
          <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-sm bg-black rounded-lg overflow-hidden relative">
              <video ref={videoRef} className="w-full aspect-[4/3] object-cover" playsInline muted />
              <div className="absolute inset-0 border-2 border-white/30 pointer-events-none">
                <div className="absolute top-1/3 left-4 right-4 h-px bg-red-500/70 animate-pulse" />
              </div>
              <Button
                variant="destructive"
                size="sm"
                onClick={stopCamera}
                className="absolute top-2 right-2 z-10"
              >
                ✕
              </Button>
            </div>
            <p className="text-white text-sm mt-3">Наведите камеру на штрихкод</p>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4 flex-wrap h-auto">
            <TabsTrigger value="list">Список</TabsTrigger>
            <TabsTrigger value="form">{editingId ? "Редактировать" : "Добавить"}</TabsTrigger>
            <TabsTrigger value="import">Импорт</TabsTrigger>
          </TabsList>

          {/* LIST */}
          <TabsContent value="list">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="relative flex-1 min-w-0">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Поиск по названию, артикулу, штрихкоду..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                  <Button variant="outline" size="sm" onClick={() => { setShowScanner(true); startCamera(); }} className="gap-1 shrink-0">
                    <ScanBarcode className="w-4 h-4" />
                    <span className="hidden md:inline">Сканер</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {displayProducts.length > 0 ? (
                  <div className="space-y-5">
                    {Array.from(byCategory.entries()).map(([cat, items]) => (
                      <div key={cat}>
                        <h3 className="text-xs font-bold text-slate-400 uppercase mb-2 tracking-wide">{cat}</h3>
                        <div className="space-y-1.5">
                          {items?.map((p) => {
                            const lowStock = Number(p.quantity) <= Number(p.minQuantity);
                            const markup = Number(p.markupPercent);
                            const isSelected = selectedIds.has(p.id);
                            return (
                              <div key={p.id} className={"flex items-center gap-2 p-2.5 md:p-3 rounded-lg border text-sm " + (isSelected ? "bg-amber-50 border-amber-300" : "bg-white")}>
                                {isAdmin && (
                                  <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(p.id)} className="shrink-0" />
                                )}
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className="font-semibold text-sm">{p.name}</span>
                                    {p.sku && <span className="text-[10px] text-slate-400">({p.sku})</span>}
                                  </div>
                                  <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5 text-xs text-slate-500">
                                    {p.barcode && <span className="bg-slate-100 px-1 rounded">{p.barcode}</span>}
                                    <span>Цена: <b className="text-slate-700">{Number(p.price).toFixed(2)} ₽</b></span>
                                    {Number(p.costPrice) > 0 && <span>Закуп: {Number(p.costPrice).toFixed(2)} ₽</span>}
                                    {markup > 0 && <span className="text-emerald-600 font-medium">+{markup}%</span>}
                                    <span className={lowStock ? "text-red-600 font-bold" : ""}>
                                      Остаток: {p.quantity} {p.unit}
                                      {lowStock && " ⚠"}
                                    </span>
                                  </div>
                                </div>
                                {isAdmin && (
                                  <div className="flex items-center gap-0.5 shrink-0">
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => startEdit(p)}><Edit3 className="w-4 h-4" /></Button>
                                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => deleteProduct.mutate({ id: p.id })}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 text-center py-8">Нет товаров</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* FORM */}
          <TabsContent value="form">
            <Card>
              <CardHeader><CardTitle>{editingId ? "Редактировать товар" : "Новый товар"}</CardTitle></CardHeader>
              <CardContent className="space-y-3 max-w-md">
                <div><Label>Название *</Label><Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="Например: Молоко 1л" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Артикул</Label><Input value={formSku} onChange={(e) => setFormSku(e.target.value)} placeholder="SKU-123" /></div>
                  <div><Label>Штрихкод</Label><Input value={formBarcode} onChange={(e) => setFormBarcode(e.target.value)} placeholder="4601234567890" /></div>
                </div>
                <div><Label>Категория</Label><Input value={formCategory} onChange={(e) => setFormCategory(e.target.value)} placeholder="Общее" /></div>
                <div className="grid grid-cols-3 gap-3">
                  <div><Label>Закуп (₽)</Label><Input type="number" value={formCostPrice} onChange={(e) => setFormCostPrice(e.target.value)} placeholder="0.00" /></div>
                  <div><Label>Наценка %</Label>
                    <div className="flex gap-1">
                      <Input type="number" value={formMarkup} onChange={(e) => setFormMarkup(e.target.value)} placeholder="30" />
                      <Button variant="outline" size="sm" onClick={calcPriceFromMarkup} className="px-2 shrink-0">=</Button>
                    </div>
                  </div>
                  <div><Label>Цена (₽)</Label><Input type="number" value={formPrice} onChange={(e) => setFormPrice(e.target.value)} placeholder="0.00" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Количество</Label><Input type="number" value={formQty} onChange={(e) => setFormQty(e.target.value)} placeholder="0" /></div>
                  <div><Label>Мин. запас</Label><Input type="number" value={formMinQty} onChange={(e) => setFormMinQty(e.target.value)} placeholder="5" /></div>
                </div>
                <div><Label>Ед. изм.</Label><Input value={formUnit} onChange={(e) => setFormUnit(e.target.value)} placeholder="шт" /></div>
                <div className="flex gap-2 pt-2">
                  <Button onClick={handleSave} disabled={createProduct.isPending || updateProduct.isPending} className="flex-1 gap-1">
                    <Plus className="w-4 h-4" />{editingId ? "Сохранить" : "Добавить"}
                  </Button>
                  {editingId && <Button variant="outline" onClick={() => { setEditingId(null); resetForm(); }}>Отмена</Button>}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* IMPORT */}
          <TabsContent value="import">
            <Card>
              <CardHeader><CardTitle>Импорт товаров</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-blue-50 rounded-lg text-sm text-blue-800 space-y-1">
                  <p className="font-medium">Поддерживаемые форматы: CSV, XLS, XLSX</p>
                  <p className="text-xs text-blue-600">
                    Колонки: name, sku, barcode, category, costPrice, price, markupPercent, quantity, unit
                    <br />или на русском: Название, Артикул, Штрихкод, Категория, Закупочная, Цена, Наценка%, Количество, Единица
                  </p>
                </div>
                <Input type="file" accept=".csv,.xls,.xlsx,.txt" onChange={handleFileUpload} />
                {importFileName && <p className="text-sm text-slate-500">Файл: {importFileName}</p>}
                {importData && (
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Строк для импорта: {importData.length}</p>
                    <div className="max-h-48 overflow-y-auto border rounded-lg">
                      <table className="w-full text-xs">
                        <thead className="bg-slate-100 sticky top-0">
                          <tr>{importData[0] && Object.keys(importData[0]).slice(0, 8).map((k) => <th key={k} className="p-2 text-left font-medium">{k}</th>)}</tr>
                        </thead>
                        <tbody>{importData.slice(0, 5).map((row, i) => <tr key={i} className="border-b">{Object.values(row).slice(0, 8).map((v, j) => <td key={j} className="p-2">{v}</td>)}</tr>)}</tbody>
                      </table>
                    </div>
                    <Button onClick={handleImport} disabled={bulkImport.isPending} className="mt-3 gap-1">
                      <Upload className="w-4 h-4" />Импортировать {importData.length} товаров
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
