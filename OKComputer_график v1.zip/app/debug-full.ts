
import { createConnection } from "mysql2/promise";

async function debug() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  // Get all work schedules
  const [rows] = await conn.execute("SELECT id, employeeId, workDate, HEX(workDate) as hexWorkDate, isWorking, HEX(isWorking) as hexIsWorking FROM workSchedules ORDER BY id DESC LIMIT 20");
  console.log("=== All workSchedules (last 20) ===");
  for (const r of rows) {
    console.log({
      id: r.id,
      employeeId: r.employeeId,
      workDate: r.workDate,
      hexWorkDate: r.hexWorkDate,
      workDateType: typeof r.workDate,
      isWorking: r.isWorking,
      hexIsWorking: r.hexIsWorking,
      isWorkingType: typeof r.isWorking,
    });
  }

  await conn.end();
}

debug().catch(console.error);
