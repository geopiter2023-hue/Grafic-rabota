-- Supabase PostgreSQL Schema
-- Run in Supabase Dashboard > SQL Editor > New query

DROP TABLE IF EXISTS inventory_items CASCADE;
DROP TABLE IF EXISTS inventory_counts CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS cash_transactions CASCADE;
DROP TABLE IF EXISTS shift_reports CASCADE;
DROP TABLE IF EXISTS work_schedules CASCADE;
DROP TABLE IF EXISTS employees CASCADE;
DROP TABLE IF EXISTS users CASCADE;

DROP TYPE IF EXISTS inventory_status CASCADE;
DROP TYPE IF EXISTS cash_type CASCADE;
DROP TYPE IF EXISTS user_role CASCADE;

CREATE TYPE user_role AS ENUM ('user', 'admin');
CREATE TYPE cash_type AS ENUM ('income', 'expense');
CREATE TYPE inventory_status AS ENUM ('draft', 'completed');

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  union_id VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255),
  email VARCHAR(320),
  avatar TEXT,
  role user_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_signin_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE employees (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name VARCHAR(255) NOT NULL,
  base_salary DECIMAL(10,2) NOT NULL DEFAULT 2300.00,
  commission_rate DECIMAL(5,2) NOT NULL DEFAULT 3.00,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE work_schedules (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  work_date VARCHAR(10) NOT NULL,
  is_working BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(employee_id, work_date)
);

CREATE TABLE shift_reports (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  report_date VARCHAR(10) NOT NULL,
  revenue DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  commission DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  salary_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cash_start DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cash_end DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE cash_transactions (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  transaction_date VARCHAR(10) NOT NULL,
  type cash_type NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  description VARCHAR(500) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  sku VARCHAR(100),
  barcode VARCHAR(50),
  category VARCHAR(100) NOT NULL DEFAULT 'Общее',
  cost_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  markup_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  quantity INTEGER NOT NULL DEFAULT 0,
  min_quantity INTEGER NOT NULL DEFAULT 5,
  unit VARCHAR(20) NOT NULL DEFAULT 'шт',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_counts (
  id SERIAL PRIMARY KEY,
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  count_date VARCHAR(10) NOT NULL,
  status inventory_status NOT NULL DEFAULT 'draft',
  notes TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_items (
  id SERIAL PRIMARY KEY,
  inventory_id INTEGER NOT NULL REFERENCES inventory_counts(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  expected_qty INTEGER NOT NULL DEFAULT 0,
  actual_qty INTEGER NOT NULL DEFAULT 0,
  difference INTEGER NOT NULL DEFAULT 0,
  notes VARCHAR(255),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Admin user
INSERT INTO users (union_id, name, role, created_at, updated_at, last_signin_at)
VALUES ('admin_1987', 'Administrator', 'admin', NOW(), NOW(), NOW());
