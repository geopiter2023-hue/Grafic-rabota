
import { createConnection } from "mysql2/promise";

async function check() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  // Check the actual column type
  const [cols] = await conn.execute("SHOW COLUMNS FROM workSchedules WHERE Field = 'workDate'");
  console.log("Column info:", cols[0]);

  // Check raw data type
  const [rows] = await conn.execute("SELECT * FROM workSchedules WHERE id = 193500");
  const row = rows[0];
  console.log("Type of workDate:", typeof row.workDate);
  console.log("workDate value:", row.workDate);
  console.log("workDate instanceof Date:", row.workDate instanceof Date);
  console.log("workDate instanceof Buffer:", row.workDate instanceof Buffer);
  if (Buffer.isBuffer(row.workDate)) {
    console.log("workDate as string:", row.workDate.toString());
  }

  // Check isWorking type
  console.log("Type of isWorking:", typeof row.isWorking);
  console.log("isWorking value:", row.isWorking);

  await conn.end();
}

check().catch(console.error);
