import { sqliteTable, integer, text, real } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  unionId: text("union_id").notNull().unique(),
  name: text("name"),
  email: text("email"),
  avatar: text("avatar"),
  role: text("role", { enum: ["user", "admin"] }).default("user").notNull(),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
  lastSignInAt: integer("last_signin_at").default(0),
});

export const employees = sqliteTable("employees", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  baseSalary: real("base_salary").default(2300).notNull(),
  commissionRate: real("commission_rate").default(3).notNull(),
  isActive: integer("is_active", { mode: "boolean" }).default(true).notNull(),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export const workSchedules = sqliteTable("work_schedules", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  workDate: text("work_date").notNull(),
  isWorking: integer("is_working", { mode: "boolean" }).default(true).notNull(),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export const shiftReports = sqliteTable("shift_reports", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  reportDate: text("report_date").notNull(),
  revenue: real("revenue").default(0).notNull(),
  commission: real("commission").default(0).notNull(),
  salaryTotal: real("salary_total").default(0).notNull(),
  cashStart: real("cash_start").default(0).notNull(),
  cashEnd: real("cash_end").default(0).notNull(),
  notes: text("notes"),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export const cashTransactions = sqliteTable("cash_transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  transactionDate: text("transaction_date").notNull(),
  type: text("type", { enum: ["income", "expense"] }).notNull(),
  amount: real("amount").notNull(),
  description: text("description").notNull(),
  createdAt: integer("created_at").default(0),
});

export const products = sqliteTable("products", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  sku: text("sku"),
  barcode: text("barcode"),
  category: text("category").default("Общее").notNull(),
  costPrice: real("cost_price").default(0).notNull(),
  price: real("price").default(0).notNull(),
  markupPercent: real("markup_percent").default(0).notNull(),
  quantity: integer("quantity").default(0).notNull(),
  minQuantity: integer("min_quantity").default(5).notNull(),
  unit: text("unit").default("шт").notNull(),
  isActive: integer("is_active", { mode: "boolean" }).default(true).notNull(),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export const inventoryCounts = sqliteTable("inventory_counts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  countDate: text("count_date").notNull(),
  status: text("status", { enum: ["draft", "completed"] }).default("draft").notNull(),
  notes: text("notes"),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export const inventoryItems = sqliteTable("inventory_items", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  inventoryId: integer("inventory_id").notNull().references(() => inventoryCounts.id, { onDelete: "cascade" }),
  productId: integer("product_id").notNull().references(() => products.id, { onDelete: "cascade" }),
  expectedQty: integer("expected_qty").default(0).notNull(),
  actualQty: integer("actual_qty").default(0).notNull(),
  difference: integer("difference").default(0).notNull(),
  notes: text("notes"),
  createdAt: integer("created_at").default(0),
  updatedAt: integer("updated_at").default(0),
});

export type User = typeof users.$inferSelect;
export type Employee = typeof employees.$inferSelect;
export type WorkSchedule = typeof workSchedules.$inferSelect;
export type ShiftReport = typeof shiftReports.$inferSelect;
export type CashTransaction = typeof cashTransactions.$inferSelect;
export type Product = typeof products.$inferSelect;
export type InventoryCount = typeof inventoryCounts.$inferSelect;
export type InventoryItem = typeof inventoryItems.$inferSelect;
