
import { createConnection } from "mysql2/promise";

async function migrate() {
  const conn = await createConnection({
    host: "ep-t4ni387b5e83b7519dc8.epsrv-t4n281l4mrmemi4zls9a.ap-southeast-1.privatelink.aliyuncs.com",
    port: 4000,
    user: "2kmDM1X4P4m3Zov.root",
    password: "rworLPME6pyC5Hm1QTl8jHP1grTfkB7L",
    database: "19e008c2-4ca2-8542-8000-09673a4d6883",
    ssl: { rejectUnauthorized: false }
  });

  // Alter workSchedules.workDate from DATE to VARCHAR(10)
  try {
    await conn.execute("ALTER TABLE workSchedules MODIFY COLUMN workDate VARCHAR(10) NOT NULL");
    console.log("workSchedules.workDate -> VARCHAR(10)");
  } catch(e) { console.log("workSchedules (may already be varchar):", e.message); }

  // Alter shiftReports.reportDate from DATE to VARCHAR(10)
  try {
    await conn.execute("ALTER TABLE shiftReports MODIFY COLUMN reportDate VARCHAR(10) NOT NULL");
    console.log("shiftReports.reportDate -> VARCHAR(10)");
  } catch(e) { console.log("shiftReports (may already be varchar):", e.message); }

  // Alter cashTransactions.transactionDate from DATE to VARCHAR(10)
  try {
    await conn.execute("ALTER TABLE cashTransactions MODIFY COLUMN transactionDate VARCHAR(10) NOT NULL");
    console.log("cashTransactions.transactionDate -> VARCHAR(10)");
  } catch(e) { console.log("cashTransactions (may already be varchar):", e.message); }

  await conn.end();
  console.log("Migration complete!");
}

migrate().catch(e => {
  console.error(e);
  process.exit(1);
});
