import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldCheck, LogIn } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: () => {
      toast.success("Вход выполнен успешно!");
      utils.invalidate().then(() => {
        navigate("/");
      });
    },
    onError: (err) => {
      toast.error(err.message || "Ошибка входа");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!login || !password) {
      toast.error("Введите логин и пароль");
      return;
    }
    loginMutation.mutate({ login, password });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center mb-3">
            <ShieldCheck className="w-6 h-6 text-indigo-600" />
          </div>
          <CardTitle className="text-2xl">Вход в систему</CardTitle>
          <p className="text-sm text-slate-500 mt-1">Админ-панель графика работы</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="login">Логин</Label>
              <Input
                id="login"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                placeholder="Введите логин"
                autoComplete="username"
              />
            </div>
            <div>
              <Label htmlFor="password">Пароль</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Введите пароль"
                autoComplete="current-password"
              />
            </div>
            <Button
              type="submit"
              className="w-full gap-2"
              disabled={loginMutation.isPending}
            >
              <LogIn className="w-4 h-4" />
              {loginMutation.isPending ? "Вход..." : "Войти"}
            </Button>
          </form>
          <p className="text-xs text-center text-slate-400 mt-4">
            Для демо: логин <strong>1987</strong>, пароль <strong>1987</strong>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
